# DATA FIX: 200 KHÔNG phải limit. kt_learn() quá tốn.

> Nox thử 5 cách, crash 5 lần, kết luận "200 limit, cần GC."
> SAI. Heap = 1GB. Nox dùng 31MB. Vấn đề = kt_learn() overhead.

---

## Tại sao crash

```
1 kt_learn(text):
  _kt_real_mol(text)  → split words → compose → ~20 temp strings
  word_index_update    → split words AGAIN → ~15 temp strings
  kt_silk_fire         → ~5 temp strings
  __heap_pin()         → pin ALL temps → permanent
  
  = ~40 temp strings × ~1KB mỗi cái = ~40KB per learn
  
200 learns = 8MB temps (pinned) + 30MB existing = 38MB → OK
500 learns = 20MB temps (pinned) + 30MB existing = 50MB → crash
  Vì heap pin nhảy liên tục → bytecode space bị squeeze

LLM load terabytes vì malloc/free (temps bị free).
Nox bump allocator → temps VĨNH VIỄN. Đó là lý do.
```

---

## Fix ① Multi-turn bootstrap (VERIFIED — NGAY BÂY GIỜ)

```
REPL = 1 process, nhiều turns. Mỗi dòng input = 1 turn.
Heap temps freed giữa turns. Pinned data sống.

printf 'line1\nline2\nline3\n' | ./origin.olang
= 3 REPL turns trong 1 process. Data persist. Temps freed.

VERIFIED:
  Turn 1: kt_learn("test1"); kt_learn("test2") → fact count = 584
  Turn 2: emit kt_fact_count() → VẪN 584! Data sống qua turns.
  Heap: 37MB → 40MB. Không crash.
```

### Cách dùng:

```bash
# Shell script feed nhiều turns:
printf 'load_batch(0);\nload_batch(1);\nload_batch(2);\n' | ./origin.olang

# Mỗi load_batch = 200 learns = 1 REPL turn
# 50 turns = 10,000 facts. Không crash vì temps freed mỗi turn.

# Hoặc generate script:
for i in $(seq 0 49); do echo "load_batch($i);"; done | ./origin.olang
# = 10,000 NRC-VAD words loaded trong 1 phút
```

---

## Fix ② kt_learn_raw(text, mol) — skip encoding

```olang
pub fn kt_learn_raw(_text, _mol) {
    _kt_ensure_init(); _bkt_init();
    push(__kt_facts, _text);
    push(__kt_facts_mol, _mol);
    let _idx = len(__kt_facts) - 1;
    push(__kt_buckets[(_kt_mol_s(_mol) * 16) + _kt_mol_r(_mol)], _idx);
    // NO _kt_real_mol (skip encoding)
    // NO word index (skip splitting)
    // NO silk fire (skip temp strings)
    // = 0 temp allocations
}

// Pre-compute mols bằng Python:
// python3 -c "for word in open('nrc_vad_top10k.txt'): print(f'{compute_mol(word)}\t{word}')"
// → file: mol\tfact per line
// Olang load: read line → split tab → kt_learn_raw(fact, mol)
// = load 10,000 facts dễ dàng
```

---

## Fix ③ Compile bằng OLANG (tốt nhất, KHÔNG Python)

```olang
// Đã có trong batch_loader.ol:
// compile_to_raw(input, output) — pure Olang, tính mol + ghi file

// Chạy 1 lần:
emit compile_to_raw("json/nrc_vad_top10k.txt", "nrc_compiled.dat");
// → 10,000 entries compiled to nrc_compiled.dat (mol\tfact per line)

// Sau đó load instant:
emit batch_load_raw("nrc_compiled.dat");
// → direct push, 0 encoding, 0 temp strings = load toàn bộ

// Olang tự compile knowledge cho mình. Không Python. Không dependency.
```

---

## LLM load terabytes. Nox CAN load 50,000.

```
Không cần GC. Không cần VM fix. Không cần Python.
Cần: tránh temp strings khi bulk load.

Fix ① = multi-turn batch (VERIFIED, dùng ngay)
Fix ② = kt_learn_raw (~20 LOC Olang)  
Fix ③ = compile_to_raw + batch_load_raw (pure Olang, ~50 LOC)

Pick one. Load data. 693 → 10,000+.
OLANG TỰ ĐỦ.
```
