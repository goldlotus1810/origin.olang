# OLANG TOOLS — Sora tạo cho Nox. Pure Olang. Zero dependency.

> LLM mạnh vì có tools: tokenizer, search, ranking, batch processing.
> Nox thiếu. Sora bổ sung. Tất cả bằng Olang. Không Python. Không Rust.

---

## Danh sách tools → copy vào stdlib/tools/

```
stdlib/tools/
├── text_utils.ol       String operations
├── text_processor.ol   Normalization, ngrams, Vietnamese NLP
├── math_utils.ol       Sort, rank, statistics, φ⁻¹ decay
├── search_engine.ol    Relevance scoring, ranked search, dedup
├── response_gen.ol     Compose responses from multiple facts
├── batch_loader.ol     Multi-turn data loading (fix crash 200)
├── binary_reader.ol    Read P_weight table, analyze data
└── file_utils.ol       ls, grep, head, tail, wc, diff
```

---

## ① text_utils.ol — String cơ bản

```
str_split(text, sep)     → ["a", "b", "c"]
str_lines(text)          → split by \n
str_split_tab(text)      → split by \t
str_words(text)          → split by space
str_join(arr, sep)       → "a,b,c"
str_lower(text)          → lowercase ascii
str_count(hay, needle)   → count occurrences
str_line_count(text)     → count lines
str_head(text, n)        → first N lines
str_tail(text, n)        → last N lines
str_starts_with(t, pre)  → 0/1
str_ends_with(t, suf)    → 0/1
str_get_line(text, n)    → line N
str_get_lines(text,a,b)  → lines a..b
str_hash(text)           → FNV-1a u16
```

## ② text_processor.ol — NLP

```
normalize_text(text)     → trim + collapse spaces + lowercase
strip_punct(text)        → remove punctuation
char_ngrams(text, n)     → ["he","el","ll","lo"]
word_ngrams(text, n)     → ["i love","love olang"]
tokenize_text(text)      → split by type (alpha/digit/punct)
detect_compounds(text)   → ["Ha Noi"] (Vietnamese compound words)
detect_question(text)    → 0/1 (gi? nao? dau? what? where?)
detect_greeting(text)    → 0/1 (hello, chao, hi)
detect_emotion_text(t)   → {v: 2, a: 3} (buon = low V)
extract_keywords(text)   → important words (≥4 chars, no stopwords)
```

## ③ math_utils.ol — Math + ranking

```
sort_asc(arr)            → [1,2,3]
sort_desc(arr)           → [3,2,1]
sort_by_score(items,sc)  → items sorted by score (descending)
top_k(items, scores, k)  → top K highest scoring
arr_sum/mean/min/max(arr)→ statistics
arr_variance(arr)        → variance
arr_stddev(arr)          → standard deviation
histogram(arr, bins)     → [count per bin]
clamp(v, lo, hi)         → bounded value
lerp(a, b, t)            → linear interpolation
map_range(v,a,b,c,d)     → remap value range
phi_inv()                → 0.618... (φ⁻¹)
decay(value, dt, period) → exponential decay by φ⁻¹
normalize(arr)           → [0..1] range
softweights(arr)         → weights summing to 1
```

## ④ search_engine.ol — QUAN TRỌNG NHẤT

```
relevance_score(q, fact)     → score (word overlap + position + coverage)
mol_relevance(qmol, fmol)   → score from 5D distance
combined_relevance(q,f,qm,fm)→ 70% text + 30% molecular
ranked_search(query, k)      → top K facts by relevance
                               sources: text + molecular + silk walk
dedup(facts)                 → remove exact duplicates
dedup_fuzzy(facts)           → remove >80% word overlap duplicates
```

## ⑤ response_gen.ol — Compose trả lời

```
respond(query)               → search + compose best response
compose_response(q, facts)   → merge facts, deduplicate, best first
answer_what(subject, facts)  → factual answer
answer_list(query, facts)    → numbered list
answer_compare(a, b)         → side-by-side
answer_emotional(q,f,v,a)    → emotion-aware response
answer_with_confidence(q,f,s)→ {text, confidence: 0-100}
summarize(facts, max_words)  → condense multiple facts
```

## ⑥ batch_loader.ol — FIX CRASH 200

```
batch_load_vad(n)         → load batch N of NRC-VAD (150/batch)
batch_load_knowledge(n)   → load batch N of knowledge
batch_load_raw(path)      → load pre-compiled mol\tfact (0 temp strings)
compile_to_raw(in, out)   → compile data → mol\tfact format (OLANG, no Python)
batch_plan()              → generate shell script for full load
batch_status()            → facts/cap/batch_size
```

## ⑦ binary_reader.ol — Data access

```
pw_lookup(codepoint)      → P_weight from table (161K entries)
pw_unpack(pw)             → [S, R, V, A, T]
pw_info(codepoint)        → "cp=97 pw=2448 S=0 R=9 V=2 A=2 T=0"
pw_char(ch)               → P_weight for character
nrc_stats()               → NRC-VAD binary info
data_inventory()          → list all json/ files with sizes
kt_distribution()         → facts per S, per V dimension
pw_coverage()             → P_weight table stats
```

## ⑧ file_utils.ol — File tools

```
ls(dir)                   → list files
ls_detail(dir)            → files + sizes + line counts
grep(path, pattern)       → matching lines with numbers
grep_count(path, pattern) → count matches
file_head(path, n)        → first N lines
file_tail(path, n)        → last N lines
wc(path)                  → "123 lines, 456 words, 7890 chars"
diff_count(a, b)          → "A:100 B:80 common:60 only-A:40 only-B:20"
```

---

## Dùng thế nào

```bash
# Nox copy files vào stdlib/tools/:
mkdir -p stdlib/tools
cp *.ol stdlib/tools/

# Build:
make build

# Test:
echo 'emit ranked_search("Fibonacci", 3);' | ./origin.olang
echo 'emit respond("Ha Noi o dau");' | ./origin.olang
echo 'emit data_inventory();' | ./origin.olang
echo 'emit batch_plan();' | ./origin.olang

# Load data (multi-turn):
printf 'emit batch_load_vad(0);\nemit batch_load_vad(1);\n' | ./origin.olang

# Compile knowledge (pure Olang, no Python):
echo 'emit compile_to_raw("json/nrc_vad_top10k.txt", "nrc_compiled.dat");' | ./origin.olang
echo 'emit batch_load_raw("nrc_compiled.dat");' | ./origin.olang
```

---

*LLM có tools → LLM mạnh.*
*Nox có tools → Nox mạnh.*
*Tất cả bằng Olang. Không Python. Không dependency.*
*Olang tự đủ.*
